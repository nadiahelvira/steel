<?php
$server="localhost:3309";
$db="wolfie";
$user="root";
$pass="123456";
$version="0.9d";
$pgport=5432;
$pchartfolder="class/pchart2";
